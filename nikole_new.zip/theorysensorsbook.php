 <?php if (($_POST["log"]=="book") && ($_POST["pas"])=="sensorstheory")
		include("theorysensorsbook.html");
	 else
	 	echo "Please try again";
?>
